# Online Pharmacy Management System
### Project title: Shaik Sumaya Tabassum

A responsive mini project built with **HTML, CSS, JavaScript, Express.js and MySQL**. Customers can browse medicines, check prices, add items to a cart and place orders. Administrators can manage medicine stock and expiry dates and update order statuses.

## Features
- Customer registration, sign-in and sign-out
- Medicine catalog with name/category search
- Cart quantity controls and order placement
- Stock validation and automatic stock deduction
- Admin dashboard with medicine, stock, order and sales summaries
- Add, edit and delete medicine inventory
- View all orders and update order status
- Password hashing using bcryptjs and session-based authentication

## Database tables
1. `users` — `user_id`, `name`, `email`, `password`, `phone`, `role`
2. `medicines` — `medicine_id`, `medicine_name`, `category`, `manufacturer`, `price`, `stock`, `expiry_date`
3. `orders` — `order_id`, `user_id`, `order_date`, `total_amount`, `status`
4. `order_items` — `item_id`, `order_id`, `medicine_id`, `quantity`, `price`

Foreign keys connect orders to users and order items to orders and medicines.

## Requirements
- Node.js and npm
- MySQL Server 8 or compatible
- VS Code (recommended)

## Setup and run

1. Extract the ZIP and open this project folder in VS Code.
2. Open MySQL Workbench or the MySQL command line and execute `database.sql`.
3. In the project terminal, install packages:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`. Update `DB_USER`, `DB_PASSWORD` and other values for your MySQL setup.
5. Start the server:

   ```bash
   npm start
   ```

6. Open **http://localhost:3000** in your browser.

## Create an admin account
Register through the website first. Then, in MySQL Workbench, run:

```sql
USE online_pharmacy;
UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
```

Sign out and sign back in. The Admin link will appear. Never expose admin access on a public deployment.

## Upload to GitHub

Create a repository named `online-pharmacy-management-system`, then run these commands from this project folder:

```bash
git init
git add .
git commit -m "Online Pharmacy Management System"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/online-pharmacy-management-system.git
git push -u origin main
```

Do not upload your `.env` file or `node_modules` folder.

## Project details
**Project title:** Shaik Sumaya Tabassum  
**Project:** Online Pharmacy Management System  
**Frontend:** HTML, CSS, JavaScript  
**Backend:** Node.js, Express.js  
**Database:** MySQL

> Academic demonstration project. This app is not a substitute for a licensed pharmacy or medical advice. Add appropriate prescription verification, privacy, payment and regulatory controls before any real-world use.
