const $ = id => document.getElementById(id);
let currentUser = null;
let medicines = [];
let cart = JSON.parse(sessionStorage.getItem("pharmacyCart") || "[]");
let toastTimer;

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "same-origin", ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function notify(message) {
  $("toast").textContent = message; $("toast").classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2600);
}
function money(value) { return "₹" + Number(value).toFixed(2); }
function saveCart() { sessionStorage.setItem("pharmacyCart", JSON.stringify(cart)); updateCartCount(); }
function updateCartCount() { $("cartCount").textContent = cart.reduce((n, x) => n + x.quantity, 0); }
function safe(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

async function loadMedicines() {
  try {
    medicines = await api("/api/medicines?search=" + encodeURIComponent($("searchInput").value));
    renderMedicines();
  } catch (e) { $("medicineGrid").innerHTML = `<div class="empty-state">${safe(e.message)}</div>`; }
}
function renderMedicines() {
  const today = new Date(); today.setHours(0,0,0,0);
  const available = medicines.filter(m => new Date(m.expiry_date).getTime() >= today.getTime());
  $("medicineGrid").innerHTML = available.length ? available.map(m => `
    <article class="medicine-card-product">
      <div class="product-icon">✚</div><span class="product-category">${safe(m.category || "Healthcare")}</span>
      <h3>${safe(m.medicine_name)}</h3><div class="manufacturer">${safe(m.manufacturer || "Manufacturer not listed")}</div>
      <div class="product-meta"><span class="price">${money(m.price)}</span><span class="stock">${m.stock > 0 ? `${m.stock} in stock` : "Out of stock"}</span></div>
      <div class="product-actions"><button class="small-btn" ${m.stock < 1 ? "disabled" : ""} onclick="addToCart(${m.medicine_id})">Add to cart</button></div>
    </article>`).join("") : `<div class="empty-state">No available medicines found. Try another search.</div>`;
}
function addToCart(id) {
  const med = medicines.find(m => m.medicine_id === id);
  if (!med) return;
  const line = cart.find(x => x.medicine_id === id);
  if (line && line.quantity >= med.stock) return notify("You have added all available stock.");
  if (line) line.quantity++; else cart.push({ medicine_id: id, quantity: 1 });
  saveCart(); notify("Added to your cart.");
}
function showModal(html) { $("modalContent").innerHTML = html; $("modalBackdrop").classList.remove("hidden"); }
function closeModal() { $("modalBackdrop").classList.add("hidden"); }
function authModal(mode = "login") {
  const register = mode === "register";
  showModal(`<h2>${register ? "Create your account" : "Welcome back"}</h2><p>${register ? "Register to place and track medicine orders." : "Sign in to continue to your pharmacy account."}</p>
    <form id="authForm">${register ? `<label>Full name<input name="name" required maxlength="100" placeholder="Your name"></label>` : ""}
    <label>Email address<input name="email" type="email" required placeholder="name@example.com"></label>
    ${register ? `<label>Phone number<input name="phone" maxlength="15" placeholder="Phone number"></label>` : ""}
    <label>Password<input name="password" type="password" required minlength="${register ? 6 : 1}" placeholder="Enter password"></label>
    <button class="btn btn-primary" type="submit">${register ? "Create account" : "Sign in"}</button></form>
    <div class="modal-switch">${register ? "Already registered?" : "New to CareNest?"} <button id="switchAuth">${register ? "Sign in" : "Create an account"}</button></div>`);
  $("authForm").addEventListener("submit", async e => {
    e.preventDefault(); const body = Object.fromEntries(new FormData(e.target).entries());
    try {
      const data = await api(register ? "/api/register" : "/api/login", { method: "POST", body: JSON.stringify(body) });
      currentUser = data.user; closeModal(); updateUserUI(); notify(register ? "Account created." : "Signed in."); 
      if (currentUser.role === "admin") loadAdmin();
    } catch (err) { notify(err.message); }
  });
  $("switchAuth").onclick = () => authModal(register ? "login" : "register");
}
function updateUserUI() {
  $("welcome").textContent = currentUser ? `Hi, ${currentUser.name.split(" ")[0]}` : "";
  $("authButton").textContent = currentUser ? "Sign out" : "Sign in";
  $("ordersLink").classList.toggle("hidden", !currentUser);
  $("adminLink").classList.toggle("hidden", !currentUser || currentUser.role !== "admin");
  $("orders").classList.toggle("hidden", !currentUser);
  $("admin").classList.toggle("hidden", !currentUser || currentUser.role !== "admin");
  if (currentUser) loadOrders();
}
async function loadCart() {
  try {
    if (!medicines.length) await loadMedicines();
    const rows = cart.map(line => ({ ...line, med: medicines.find(m => m.medicine_id === line.medicine_id) })).filter(x => x.med);
    const total = rows.reduce((s, x) => s + Number(x.med.price) * x.quantity, 0);
    showModal(`<h2>Your cart</h2><p>Review your items before placing the order.</p>
      ${rows.length ? rows.map(x => `<div class="cart-line"><div><strong>${safe(x.med.medicine_name)}</strong><br><small>${money(x.med.price)} each</small></div><div class="qty-controls"><button onclick="changeQty(${x.med.medicine_id},-1)">−</button><b>${x.quantity}</b><button onclick="changeQty(${x.med.medicine_id},1)">+</button></div></div>`).join("") : `<div class="empty-state">Your cart is empty.</div>`}
      <div class="cart-total"><span>Total</span><span>${money(total)}</span></div>
      <button class="btn btn-primary" style="width:100%" id="checkoutButton" ${rows.length ? "" : "disabled"}>Place order</button>
      ${!currentUser ? `<p style="text-align:center">Please sign in before placing an order.</p>` : ""}`);
    $("checkoutButton").onclick = checkout;
  } catch (e) { notify(e.message); }
}
function changeQty(id, delta) {
  const line = cart.find(x => x.medicine_id === id), med = medicines.find(x => x.medicine_id === id);
  if (!line) return;
  line.quantity += delta;
  if (line.quantity < 1) cart = cart.filter(x => x.medicine_id !== id);
  else if (med && line.quantity > med.stock) { line.quantity = med.stock; notify("Maximum available stock reached."); }
  saveCart(); loadCart();
}
async function checkout() {
  if (!currentUser) return authModal();
  try {
    const result = await api("/api/orders", { method: "POST", body: JSON.stringify({ items: cart }) });
    cart = []; saveCart(); closeModal(); notify(`Order #${result.order_id} placed successfully.`);
    await loadMedicines(); await loadOrders();
    if (currentUser.role === "admin") loadAdmin();
  } catch (e) { notify(e.message); await loadMedicines(); }
}
async function loadOrders() {
  if (!currentUser) return;
  try {
    const rows = await api("/api/orders");
    $("ordersList").innerHTML = rows.length ? rows.map(o => `<div class="order-card"><div><strong>Order #${o.order_id}</strong><p>${safe(o.items)} · ${new Date(o.order_date).toLocaleDateString("en-IN")}</p><strong>${money(o.total_amount)}</strong></div><span class="status">${safe(o.status)}</span></div>`).join("") : `<div class="empty-state">You have not placed any orders yet.</div>`;
  } catch (e) { $("ordersList").innerHTML = `<div class="empty-state">${safe(e.message)}</div>`; }
}
async function loadAdmin() {
  if (!currentUser || currentUser.role !== "admin") return;
  try {
    const d = await api("/api/dashboard");
    $("stats").innerHTML = [["Medicines",d.medicine_count],["Total stock",d.total_stock],["Orders",d.order_count],["Sales",money(d.sales_total)]].map(([a,b]) => `<div class="stat"><span>${a}</span><strong>${b ?? 0}</strong></div>`).join("");
    await renderInventory(); await renderAdminOrders();
  } catch (e) { notify(e.message); }
}
async function renderInventory() {
  const rows = await api("/api/medicines");
  $("inventoryTable").innerHTML = `<table class="data-table"><thead><tr><th>Medicine</th><th>Price</th><th>Stock</th><th>Expiry</th><th>Actions</th></tr></thead><tbody>${rows.map(m => `<tr><td>${safe(m.medicine_name)}</td><td>${money(m.price)}</td><td>${m.stock}</td><td>${new Date(m.expiry_date).toLocaleDateString("en-IN")}</td><td><button class="table-action" onclick="editMedicine(${m.medicine_id})">Edit</button><button class="table-action danger" onclick="deleteMedicine(${m.medicine_id})">Delete</button></td></tr>`).join("")}</tbody></table>`;
}
async function renderAdminOrders() {
  const rows = await api("/api/orders");
  $("adminOrders").innerHTML = rows.length ? `<table class="data-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Update</th></tr></thead><tbody>${rows.map(o => `<tr><td>#${o.order_id}</td><td>${safe(o.customer_name)}</td><td>${safe(o.items)}</td><td>${money(o.total_amount)}</td><td>${safe(o.status)}</td><td><select onchange="updateOrderStatus(${o.order_id},this.value)">${["Placed","Processing","Dispatched","Delivered","Cancelled"].map(s => `<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("")}</tbody></table>` : `<div class="empty-state">No orders yet.</div>`;
}
function clearMedicineForm() { $("medicineForm").reset(); $("medicineId").value = ""; $("medicineFormTitle").textContent = "Add a medicine"; }
async function editMedicine(id) {
  const m = (await api("/api/medicines")).find(x => x.medicine_id === id); if (!m) return;
  $("medicineId").value = m.medicine_id; $("medName").value = m.medicine_name; $("medCategory").value = m.category;
  $("medManufacturer").value = m.manufacturer; $("medPrice").value = m.price; $("medStock").value = m.stock;
  $("medExpiry").value = new Date(m.expiry_date).toISOString().slice(0,10); $("medicineFormTitle").textContent = "Update medicine";
  $("medicineForm").scrollIntoView({ behavior: "smooth", block: "center" });
}
async function deleteMedicine(id) {
  if (!confirm("Delete this medicine from inventory?")) return;
  try { await api(`/api/medicines/${id}`, { method: "DELETE" }); notify("Medicine deleted."); await loadMedicines(); await loadAdmin(); }
  catch (e) { notify(e.message); }
}
async function updateOrderStatus(id, status) {
  try { await api(`/api/orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }); notify("Order status updated."); await renderAdminOrders(); }
  catch (e) { notify(e.message); }
}

$("authButton").onclick = async () => {
  if (!currentUser) return authModal();
  try { await api("/api/logout", { method: "POST" }); currentUser = null; updateUserUI(); notify("Signed out."); }
  catch (e) { notify(e.message); }
};
$("cartButton").onclick = loadCart;
$("modalClose").onclick = closeModal;
$("modalBackdrop").addEventListener("click", e => { if (e.target === $("modalBackdrop")) closeModal(); });
$("searchInput").addEventListener("input", loadMedicines);
$("resetMedicine").onclick = clearMedicineForm;
$("medicineForm").addEventListener("submit", async e => {
  e.preventDefault();
  const id = $("medicineId").value;
  const body = { medicine_name:$("medName").value, category:$("medCategory").value, manufacturer:$("medManufacturer").value, price:$("medPrice").value, stock:$("medStock").value, expiry_date:$("medExpiry").value };
  try {
    await api(id ? `/api/medicines/${id}` : "/api/medicines", { method: id ? "PUT" : "POST", body: JSON.stringify(body) });
    notify(id ? "Medicine updated." : "Medicine added."); clearMedicineForm(); await loadMedicines(); await loadAdmin();
  } catch (err) { notify(err.message); }
});
async function init() {
  updateCartCount(); await loadMedicines();
  try { const d = await api("/api/me"); currentUser = d.user; updateUserUI(); if (currentUser?.role === "admin") loadAdmin(); }
  catch (e) { console.error(e); }
}
init();
