require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 1000 * 60 * 60 * 4 }
}));
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "online_pharmacy",
  waitForConnections: true,
  connectionLimit: 10
});

const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const requireLogin = (req, res, next) => req.session.user ? next() : res.status(401).json({ error: "Please sign in first." });
const requireAdmin = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in first." });
  if (req.session.user.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
};

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/register", asyncRoute(async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: "Name, email and password are required." });
  if (password.length < 6) return res.status(400).json({ error: "Password must contain at least 6 characters." });
  const hash = await bcrypt.hash(password, 10);
  try {
    const [result] = await pool.execute(
      "INSERT INTO users (name,email,password,phone,role) VALUES (?,?,?,?, 'customer')",
      [name.trim(), email.trim().toLowerCase(), hash, phone || null]
    );
    req.session.user = { user_id: result.insertId, name: name.trim(), email: email.trim().toLowerCase(), role: "customer" };
    res.status(201).json({ user: req.session.user });
  } catch (e) {
    if (e.code === "ER_DUP_ENTRY") return res.status(409).json({ error: "This email is already registered." });
    throw e;
  }
}));

app.post("/api/login", asyncRoute(async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await pool.execute("SELECT * FROM users WHERE email = ?", [(email || "").trim().toLowerCase()]);
  if (!rows.length || !(await bcrypt.compare(password || "", rows[0].password))) {
    return res.status(401).json({ error: "Invalid email or password." });
  }
  const u = rows[0];
  req.session.user = { user_id: u.user_id, name: u.name, email: u.email, role: u.role };
  res.json({ user: req.session.user });
}));

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ message: "Signed out." })));

app.get("/api/medicines", asyncRoute(async (req, res) => {
  const search = `%${req.query.search || ""}%`;
  const [rows] = await pool.execute(
    "SELECT medicine_id, medicine_name, category, manufacturer, price, stock, expiry_date FROM medicines WHERE medicine_name LIKE ? OR category LIKE ? ORDER BY medicine_name",
    [search, search]
  );
  res.json(rows);
}));

app.post("/api/medicines", requireAdmin, asyncRoute(async (req, res) => {
  const { medicine_name, category, manufacturer, price, stock, expiry_date } = req.body;
  if (!medicine_name || !expiry_date || Number(price) < 0 || Number(stock) < 0) return res.status(400).json({ error: "Enter valid medicine details." });
  const [r] = await pool.execute(
    "INSERT INTO medicines (medicine_name,category,manufacturer,price,stock,expiry_date) VALUES (?,?,?,?,?,?)",
    [medicine_name, category || "", manufacturer || "", Number(price), Number(stock), expiry_date]
  );
  res.status(201).json({ medicine_id: r.insertId, message: "Medicine added." });
}));

app.put("/api/medicines/:id", requireAdmin, asyncRoute(async (req, res) => {
  const { medicine_name, category, manufacturer, price, stock, expiry_date } = req.body;
  await pool.execute(
    "UPDATE medicines SET medicine_name=?,category=?,manufacturer=?,price=?,stock=?,expiry_date=? WHERE medicine_id=?",
    [medicine_name, category || "", manufacturer || "", Number(price), Number(stock), expiry_date, req.params.id]
  );
  res.json({ message: "Medicine updated." });
}));

app.delete("/api/medicines/:id", requireAdmin, asyncRoute(async (req, res) => {
  try {
    const [r] = await pool.execute("DELETE FROM medicines WHERE medicine_id=?", [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ error: "Medicine not found." });
    res.json({ message: "Medicine deleted." });
  } catch (e) {
    if (e.code === "ER_ROW_IS_REFERENCED_2") return res.status(409).json({ error: "This medicine is part of an order and cannot be deleted." });
    throw e;
  }
}));

app.post("/api/orders", requireLogin, asyncRoute(async (req, res) => {
  const items = req.body.items;
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Your cart is empty." });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    let total = 0;
    const validated = [];
    for (const item of items) {
      const qty = Math.floor(Number(item.quantity));
      if (!Number.isInteger(Number(item.medicine_id)) || qty < 1) throw new Error("Invalid cart item.");
      const [rows] = await conn.execute("SELECT * FROM medicines WHERE medicine_id=? FOR UPDATE", [item.medicine_id]);
      if (!rows.length) throw new Error("A selected medicine is no longer available.");
      const med = rows[0];
      if (med.stock < qty) throw new Error(`Only ${med.stock} unit(s) of ${med.medicine_name} are in stock.`);
      if (new Date(med.expiry_date) < new Date(new Date().toDateString())) throw new Error(`${med.medicine_name} has expired and cannot be ordered.`);
      const price = Number(med.price);
      total += price * qty;
      validated.push({ medicine_id: med.medicine_id, quantity: qty, price, stock: med.stock });
    }
    const [order] = await conn.execute(
      "INSERT INTO orders (user_id,order_date,total_amount,status) VALUES (?,CURDATE(),?,'Placed')",
      [req.session.user.user_id, total.toFixed(2)]
    );
    for (const item of validated) {
      await conn.execute(
        "INSERT INTO order_items (order_id,medicine_id,quantity,price) VALUES (?,?,?,?)",
        [order.insertId, item.medicine_id, item.quantity, item.price]
      );
      await conn.execute("UPDATE medicines SET stock=stock-? WHERE medicine_id=?", [item.quantity, item.medicine_id]);
    }
    await conn.commit();
    res.status(201).json({ order_id: order.insertId, total_amount: total.toFixed(2), message: "Order placed successfully." });
  } catch (e) {
    await conn.rollback();
    res.status(400).json({ error: e.message });
  } finally { conn.release(); }
}));

app.get("/api/orders", requireLogin, asyncRoute(async (req, res) => {
  const isAdmin = req.session.user.role === "admin";
  const sql = `SELECT o.order_id,o.user_id,u.name AS customer_name,o.order_date,o.total_amount,o.status,
    GROUP_CONCAT(CONCAT(m.medicine_name,' × ',oi.quantity) SEPARATOR ', ') AS items
    FROM orders o JOIN users u ON o.user_id=u.user_id
    JOIN order_items oi ON o.order_id=oi.order_id JOIN medicines m ON oi.medicine_id=m.medicine_id
    ${isAdmin ? "" : "WHERE o.user_id = ?"}
    GROUP BY o.order_id ORDER BY o.order_id DESC`;
  const [rows] = await pool.execute(sql, isAdmin ? [] : [req.session.user.user_id]);
  res.json(rows);
}));

app.patch("/api/orders/:id/status", requireAdmin, asyncRoute(async (req, res) => {
  const allowed = ["Placed", "Processing", "Dispatched", "Delivered", "Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid order status." });
  const [r] = await pool.execute("UPDATE orders SET status=? WHERE order_id=?", [req.body.status, req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ error: "Order not found." });
  res.json({ message: "Order status updated." });
}));

app.get("/api/dashboard", requireAdmin, asyncRoute(async (req, res) => {
  const [[m]] = await pool.query("SELECT COUNT(*) AS medicine_count, COALESCE(SUM(stock),0) AS total_stock, SUM(expiry_date < CURDATE()) AS expired_count FROM medicines");
  const [[o]] = await pool.query("SELECT COUNT(*) AS order_count, COALESCE(SUM(total_amount),0) AS sales_total FROM orders");
  const [[u]] = await pool.query("SELECT COUNT(*) AS user_count FROM users");
  res.json({ ...m, ...o, ...u });
}));

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong. Check the server and database settings." });
});

app.listen(PORT, () => console.log(`Online Pharmacy running at http://localhost:${PORT}`));
