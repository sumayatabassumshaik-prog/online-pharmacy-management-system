CREATE DATABASE IF NOT EXISTS online_pharmacy;
USE online_pharmacy;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(15),
  role VARCHAR(20) NOT NULL DEFAULT 'customer'
);

CREATE TABLE IF NOT EXISTS medicines (
  medicine_id INT AUTO_INCREMENT PRIMARY KEY,
  medicine_name VARCHAR(150) NOT NULL,
  category VARCHAR(50),
  manufacturer VARCHAR(100),
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  expiry_date DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  order_date DATE NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'Placed',
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS order_items (
  item_id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  medicine_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_items_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id)
);

-- Demo medicines. Add more from the admin dashboard.
INSERT INTO medicines (medicine_name, category, manufacturer, price, stock, expiry_date)
SELECT * FROM (
  SELECT 'Paracetamol 500mg', 'Pain Relief', 'HealthCare Labs', 25.00, 120, '2027-12-31'
  UNION ALL SELECT 'Cetirizine 10mg', 'Allergy', 'MediLife', 18.50, 80, '2027-08-31'
  UNION ALL SELECT 'Vitamin C 500mg', 'Vitamins', 'NutriWell', 65.00, 45, '2027-05-31'
  UNION ALL SELECT 'Antacid Tablets', 'Digestive Care', 'CarePlus', 42.00, 60, '2027-11-30'
) AS demo
WHERE NOT EXISTS (SELECT 1 FROM medicines LIMIT 1);
